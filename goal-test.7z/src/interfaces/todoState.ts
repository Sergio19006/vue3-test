import todoItem from "./todoItem";

export default interface todoState {
  todos: Array<todoItem>;
}

export default interface todoItem {
  name: string;
  done: boolean;
  id: string;
  readonly: boolean;
}
